﻿Console.WriteLine("Conditionals");

bool gradeOverMinimun = true;
bool enoughAssistance = true;
bool participatesInClass = true;
bool expelled = false;
bool suspended = false;

if(gradeOverMinimun & enoughAssistance & participatesInClass & !(expelled & suspended)){
    Console.WriteLine("Student passed");
} else {
    Console.WriteLine("Student did NOT passed");
}
Console.WriteLine("End of execution");


// 1 * 0 = 0 | true & false = false
// 0 * 1 = 0 | false & true = false
// 1 * 1 = 1 | true & true = false
// 0 * 0 = 0 | false & false = false

